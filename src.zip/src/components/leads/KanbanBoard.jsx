import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { useCRMStore } from "../../store/crmStore";

const STAGES = ["New", "Contacted", "Proposal", "Won"];

export default function KanbanBoard() {
  const leads = useCRMStore((state) => state.leads);
  const moveLead = useCRMStore((state) => state.moveLead);

  // Group leads by stage
  const groupedLeads = STAGES.reduce((acc, stage) => {
    acc[stage] = leads.filter((lead) => lead.stage === stage);
    return acc;
  }, {});

  const onDragEnd = (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    )
      return;

    moveLead(draggableId, destination.droppableId);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {STAGES.map((stage) => (
          <Droppable droppableId={stage} key={stage}>
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={`bg-gray-100 p-3 rounded shadow min-h-[200px] transition-all ${
                  snapshot.isDraggingOver ? "bg-blue-100" : ""
                }`}
              >
                <h3 className="text-lg font-semibold mb-2">{stage}</h3>

                {groupedLeads[stage].map((lead, index) => (
                  <Draggable
                    key={lead.id}
                    draggableId={lead.id}
                    index={index}
                  >
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className={`p-3 mb-2 rounded bg-white shadow text-sm font-medium ${
                          snapshot.isDragging ? "bg-blue-50" : ""
                        }`}
                      >
                        {lead.name}
                      </div>
                    )}
                  </Draggable>
                ))}

                {provided.placeholder}
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}
