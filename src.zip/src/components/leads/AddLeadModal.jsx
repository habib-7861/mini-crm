import { useState } from "react";
import { useCRMStore } from "../../store/crmStore";

const STAGES = ["New", "Contacted", "Proposal", "Won"];

export default function AddLeadModal({ isOpen, onClose }) {
  const [name, setName] = useState("");
  const [stage, setStage] = useState("New");
  const addLead = useCRMStore.setState;

  const handleSubmit = () => {
    if (!name.trim()) return;

    const newLead = {
      id: Date.now().toString(),
      name,
      stage,
    };

    addLead((state) => ({
      leads: [...state.leads, newLead],
    }));

    setName("");
    setStage("New");
    onClose(); // Close modal after add
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-96">
        <h2 className="text-lg font-bold mb-4 text-gray-700">Add New Lead</h2>

        <input
          type="text"
          placeholder="Lead Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border px-3 py-2 mb-3 w-full rounded"
        />

        <select
          value={stage}
          onChange={(e) => setStage(e.target.value)}
          className="border px-2 py-2 mb-4 w-full rounded"
        >
          {STAGES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>

        <div className="flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border rounded text-gray-600 hover:bg-gray-100"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
