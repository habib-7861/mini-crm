// src/components/Leads/LeadCard.jsx

export default function LeadCard({ name, stage }) {
  return (
    <div className="p-3 mb-2 rounded bg-white shadow text-sm font-medium border-l-4 border-blue-500">
      <div className="text-gray-800">{name}</div>
      <div className="text-xs text-gray-400 mt-1">Stage: {stage}</div>
    </div>
  );
}
