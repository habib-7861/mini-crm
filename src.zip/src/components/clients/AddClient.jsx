import { useState } from 'react';
import useCRMStore from '../../store/useCRMStore';

const AddClientModal = ({ onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const addClient = useCRMStore((state) => state.addClient);

  const handleSubmit = () => {
    addClient({ id: Date.now(), name, email });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-xl w-96">
        <h2 className="text-lg font-bold mb-4">Add Client</h2>
        <input
          className="w-full border p-2 rounded mb-2"
          placeholder="Client Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          className="w-full border p-2 rounded mb-4"
          placeholder="Client Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={handleSubmit}
        >
          Save
        </button>
      </div>
    </div>
  );
};

export default AddClientModal;
