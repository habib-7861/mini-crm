import useCRMStore from '../../store/useCRMStore';

const ClientList = () => {
  const clients = useCRMStore((state) => state.clients);

  return (
    <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
      {clients.map((client) => (
        <div
          key={client.id}
          className="p-4 bg-white rounded-xl shadow hover:bg-gray-100"
        >
          <h2 className="text-xl font-semibold">{client.name}</h2>
          <p>{client.email}</p>
        </div>
      ))}
    </div>
  );
};

export default ClientList;
