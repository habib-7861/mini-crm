import { useCRMStore } from "../../store/crmStore";

export default function TaskList({ forId }) {
  const tasks = useCRMStore((state) =>
    state.tasks.filter((task) => task.forId === forId)
  );
  const setTasks = useCRMStore.setState;

  const toggleDone = (id) => {
    setTasks((state) => ({
      tasks: state.tasks.map((task) =>
        task.id === id ? { ...task, done: !task.done } : task
      ),
    }));
  };

  const deleteTask = (id) => {
    setTasks((state) => ({
      tasks: state.tasks.filter((task) => task.id !== id),
    }));
  };

  return (
    <div className="mt-4">
      <h3 className="text-md font-semibold mb-2 text-gray-700">Tasks</h3>
      <ul className="space-y-2">
        {tasks.map((task) => (
          <li
            key={task.id}
            className={`flex justify-between items-center p-3 border rounded shadow ${
              task.done ? "bg-green-100" : "bg-white"
            }`}
          >
            <div>
              <p className={`text-sm ${task.done ? "line-through" : ""}`}>
                {task.title}
              </p>
              <p className="text-xs text-gray-500">Due: {task.dueDate}</p>
            </div>
            <div className="space-x-2 text-sm">
              <button
                onClick={() => toggleDone(task.id)}
                className="text-blue-600 hover:underline"
              >
                {task.done ? "Undo" : "Done"}
              </button>
              <button
                onClick={() => deleteTask(task.id)}
                className="text-red-600 hover:underline"
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
