import { useCRMStore } from "../../store/crmStore";

export default function CalendarView() {
  const tasks = useCRMStore((state) => state.tasks);

  const grouped = tasks.reduce((acc, task) => {
    acc[task.dueDate] = acc[task.dueDate] || [];
    acc[task.dueDate].push(task);
    return acc;
  }, {});

  const sortedDates = Object.keys(grouped).sort();

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Calendar View</h2>

      {sortedDates.length === 0 ? (
        <p className="text-gray-500">No tasks available.</p>
      ) : (
        sortedDates.map((date) => (
          <div key={date} className="mb-6">
            <h3 className="font-semibold text-gray-700 mb-2">{date}</h3>
            <ul className="space-y-2">
              {grouped[date].map((task) => (
                <li
                  key={task.id}
                  className={`p-3 border rounded shadow ${
                    task.done ? "bg-green-100" : "bg-white"
                  }`}
                >
                  <p className="text-sm font-medium">{task.title}</p>
                  <p className="text-xs text-gray-500">
                    Linked to ID: {task.forId}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
    </div>
  );
}
