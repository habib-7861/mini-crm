// src/components/Notes/NoteEditor.jsx
import { useState } from "react";
import { useCRMStore } from "../../store/crmStore";

export default function NoteEditor({ clientId }) {
  const [noteText, setNoteText] = useState("");
  const [editingId, setEditingId] = useState(null);
  const notes = useCRMStore((state) =>
    state.notes.filter((n) => n.clientId === clientId)
  );
  const setNotes = useCRMStore.setState;

  const handleAdd = () => {
    if (!noteText.trim()) return;

    const newNote = {
      id: Date.now().toString(),
      clientId,
      text: noteText,
    };

    setNotes((state) => ({
      notes: [...state.notes, newNote],
    }));
    setNoteText("");
  };

  const handleDelete = (id) => {
    setNotes((state) => ({
      notes: state.notes.filter((note) => note.id !== id),
    }));
  };

  const handleEdit = (note) => {
    setNoteText(note.text);
    setEditingId(note.id);
  };

  const handleUpdate = () => {
    setNotes((state) => ({
      notes: state.notes.map((note) =>
        note.id === editingId ? { ...note, text: noteText } : note
      ),
    }));
    setNoteText("");
    setEditingId(null);
  };

  return (
    <div className="mt-4">
      <h3 className="text-md font-semibold mb-2 text-gray-700">Notes</h3>

      <textarea
        value={noteText}
        onChange={(e) => setNoteText(e.target.value)}
        rows={3}
        className="w-full border px-3 py-2 mb-2 rounded"
        placeholder="Write a note..."
      />

      {editingId ? (
        <button
          onClick={handleUpdate}
          className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600 mr-2"
        >
          Update
        </button>
      ) : (
        <button
          onClick={handleAdd}
          className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
        >
          Add Note
        </button>
      )}

      <div className="mt-4 space-y-3">
        {notes.map((note) => (
          <div
            key={note.id}
            className="bg-yellow-100 p-3 rounded shadow flex justify-between items-center"
          >
            <p className="text-sm text-gray-800">{note.text}</p>
            <div className="space-x-2 text-sm">
              <button
                onClick={() => handleEdit(note)}
                className="text-blue-600 hover:underline"
              >
                Edit
              </button>
              <button
                onClick={() => handleDelete(note.id)}
                className="text-red-600 hover:underline"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
