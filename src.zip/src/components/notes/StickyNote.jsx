// src/components/Notes/StickyNotes.jsx
import { useState } from "react";
import { useCRMStore } from "../../store/crmStore";

export default function StickyNotes({ clientId }) {
  const [text, setText] = useState("");
  const [editingId, setEditingId] = useState(null);
  const notes = useCRMStore((state) =>
    state.notes.filter((n) => n.clientId === clientId)
  );
  const setNotes = useCRMStore.setState;

  const addNote = () => {
    if (!text.trim()) return;

    const newNote = {
      id: Date.now().toString(),
      clientId,
      text,
    };

    setNotes((state) => ({
      notes: [...state.notes, newNote],
    }));

    setText("");
  };

  const deleteNote = (id) => {
    setNotes((state) => ({
      notes: state.notes.filter((n) => n.id !== id),
    }));
  };

  const startEdit = (note) => {
    setText(note.text);
    setEditingId(note.id);
  };

  const updateNote = () => {
    setNotes((state) => ({
      notes: state.notes.map((n) =>
        n.id === editingId ? { ...n, text } : n
      ),
    }));
    setText("");
    setEditingId(null);
  };

  return (
    <div className="p-4">
      <h3 className="text-lg font-semibold mb-3">Sticky Notes</h3>

      <textarea
        className="w-full border px-3 py-2 rounded mb-2"
        rows="3"
        placeholder="Write a sticky note..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      {editingId ? (
        <button
          onClick={updateNote}
          className="bg-yellow-500 text-white px-4 py-1 rounded mr-2 hover:bg-yellow-600"
        >
          Update
        </button>
      ) : (
        <button
          onClick={addNote}
          className="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
        >
          Add Note
        </button>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
        {notes.map((note) => (
          <div
            key={note.id}
            className="bg-yellow-200 text-gray-800 p-4 rounded shadow relative"
          >
            <p className="text-sm">{note.text}</p>

            <div className="absolute top-1 right-2 space-x-2 text-xs">
              <button
                className="text-blue-700 hover:underline"
                onClick={() => startEdit(note)}
              >
                Edit
              </button>
              <button
                className="text-red-600 hover:underline"
                onClick={() => deleteNote(note.id)}
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
