import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import Clients from "./pages/Clients";
import ClientDetail from "./pages/ClientDetail";
import Leads from "./pages/Leads";
import LeadDetail from "./pages/LeadDetail";
import Tasks from "./pages/Tasks";
import NotFound from "./pages/NotFound";
import Navbar from "./components/Navbar";

// Components you want to route separately (if desired)
import AddClientModal from "./components/Clients/AddClientModal";
import AddLeadModal from "./components/leads/AddLeadModal";
import KanbanBoard from "./components/leads/KanbanBoard";
import NoteEditor from "./components/notes/NoteEditor";
import StickyNotes from "./components/Notes/StickyNotes";
import TaskList from "./components/tasks/TaskList";
import CalendarView from "./components/tasks/CalendarView";

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />

        <main className="flex-grow p-4 bg-gray-100">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />

            <Route path="/clients" element={<Clients />} />
            <Route path="/clients/:clientId" element={<ClientDetail />} />

            <Route path="/leads" element={<Leads />} />
            <Route path="/leads/:leadId" element={<LeadDetail />} />

            <Route path="/tasks" element={<Tasks />} />

            {/* Component routes for demonstration/testing */}
            <Route path="/add-client-modal" element={<AddClientModal />} />
            <Route path="/add-lead-modal" element={<AddLeadModal />} />
            <Route path="/kanban" element={<KanbanBoard />} />
            <Route path="/notes-editor" element={<NoteEditor clientId={'test-client'} />} />
            <Route path="/sticky-notes" element={<StickyNotes clientId={'test-client'} />} />
            <Route path="/task-list" element={<TaskList forId={'test-client'} />} />
            <Route path="/calendar" element={<CalendarView />} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
